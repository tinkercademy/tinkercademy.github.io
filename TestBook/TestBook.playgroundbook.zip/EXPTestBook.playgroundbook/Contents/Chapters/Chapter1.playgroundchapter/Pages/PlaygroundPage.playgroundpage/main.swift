//#-hidden-code
//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  The Swift file containing the source code edited by the user of this playground book.
//

import PlaygroundSupport
import Foundation

public enum OperationType {
    case jump
    case move
}

public struct Operation {
    var type: OperationType
    var cord: [Double]
    
    init(type: OperationType, cord: [Double]) {
        self.type = type
        self.cord = cord
    }
    
    init(dict: [String: Any]) {
        self.type = dict["type"] as! OperationType
        self.cord = dict["cord"] as! [Double]
    }
}

var instructions : [[Operation]] = []

class MessageHandler: PlaygroundRemoteLiveViewProxyDelegate {
    func remoteLiveViewProxy(
        _ remoteLiveViewProxy: PlaygroundRemoteLiveViewProxy,
        received message: PlaygroundValue
    ) {
        print("Received a message from the always-on live view", message)
    }

    func remoteLiveViewProxyConnectionClosed(_ remoteLiveViewProxy: PlaygroundRemoteLiveViewProxy) {}
}

guard let remoteView = PlaygroundPage.current.liveView as? PlaygroundRemoteLiveViewProxy else {
    fatalError("Always-on live view not configured in this page's LiveView.swift.")
}

remoteView.delegate = MessageHandler()

func cordArrayToPlaygroundValue(cord: [[Operation]]) -> PlaygroundValue {
    return PlaygroundValue.array(cord.map {
        PlaygroundValue.array($0.map {
            PlaygroundValue.dictionary([
                "type": PlaygroundValue.integer($0.type == .jump ? 0 : 1),
                "cord": PlaygroundValue.array([
                    PlaygroundValue.floatingPoint($0.cord[0]),
                    PlaygroundValue.floatingPoint($0.cord[1])
                ])
            ])
        })
    })
}

var currentPos: [Double] = [0, 0]
var currentAngle: Double = 0

func goForward(distance: Double) {
    
    if (distance == 0) { return }
    
    let radians = currentAngle * ( Double.pi / 180 )
    let dy = distance * sin(radians)
    let dx = distance * cos(radians)
    
    instructions.append([
        Operation(type: .move, cord: currentPos),
        Operation(type: .move, cord: [currentPos[0] + dx, currentPos[1] + dy])
    ])
    currentPos = [currentPos[0] + dx, currentPos[1] + dy]
}

func moveTo(cord: (Double, Double)) {
    instructions.append([
        Operation(type: .jump, cord: currentPos),
        Operation(type: .jump, cord: [cord.0, cord.1])
    ])
    currentPos = [cord.0, cord.1]
}

func rotate(angle: Double) {
    currentAngle += angle
    if (angle >= 360) { currentAngle -= 360 }
}

//#-end-hidden-code
//#-editable-code
// Type your code here

//#-end-editable-code
//#-hidden-code
remoteView.send(cordArrayToPlaygroundValue(cord: instructions))
//#-end-hidden-code
