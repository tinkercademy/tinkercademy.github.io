//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  Instantiates a live view and passes it to the PlaygroundSupport framework.
//

import Foundation
import UIKit
import PlaygroundSupport

fileprivate protocol AnimationLooperDelegate: class {
    func turtleAnimatorDidEnd(_ animator: TurtleAnimator)
}

fileprivate class TurtleAnimator: NSObject, CAAnimationDelegate {
    var turtleLayer: CALayer = {
        let layer = CATextLayer()
        layer.bounds = CGRect(x: 0, y: 0, width: 50, height: 50)
        layer.string = "🐢"
        return layer
    }()
    
    var layers: [CAShapeLayer]
    var index = 0
    var showTurtle: Bool
    weak var delegate: AnimationLooperDelegate?
    
    deinit {
        turtleLayer.removeFromSuperlayer()
        self.layers.forEach { layer in
            layer.removeAllAnimations()
        }
    }
    
    init(_ layers: [CAShapeLayer], showTurtle: Bool = false) {
        self.layers = layers
        self.showTurtle = showTurtle
        super.init()
        if self.layers.count > 0 {
            self.scheduleAnimation(layers[index])
        } else {
            delegate?.turtleAnimatorDidEnd(self)
        }
    }
    
    public func animationDidStop(_ anim: CAAnimation, finished flag: Bool) {
        layers[index].removeAllAnimations()
        turtleLayer.removeAllAnimations()
        CATransaction.begin()
        CATransaction.disableActions()
        turtleLayer.removeFromSuperlayer()
        CATransaction.commit()
        
        if index < layers.count - 1 {
            index += 1
            scheduleAnimation(layers[index])
        }
    }
    
    func scheduleAnimation(_ layer: CAShapeLayer) {
        let duration = 3.0 / Double(layers.count)
        let animation = CABasicAnimation(keyPath: "strokeEnd")
        animation.fromValue = 0.0
        animation.toValue = 1.0
        animation.delegate = self
        animation.duration = duration
        layer.strokeEnd = 1.0
        layer.add(animation, forKey: nil)
        
        if showTurtle {
            CATransaction.begin()
            CATransaction.disableActions()
            layer.addSublayer(turtleLayer)
            CATransaction.commit()
            
            let movingAnimation = CAKeyframeAnimation(keyPath: "position")
            movingAnimation.path = layer.path
            movingAnimation.duration = duration
            turtleLayer.add(movingAnimation, forKey: nil)
        }
    }
}

public enum OperationType {
    case jump
    case move
}

public struct Operation {
    var type: OperationType
    var cord: [Double]
    
    init(type: OperationType, cord: [Double]) {
        self.type = type
        self.cord = cord
    }
    
    init(dict: [String: Any]) {
        self.type = dict["type"] as! OperationType
        self.cord = dict["cord"] as! [Double]
    }
}

class SomeViewController: UIViewController, AnimationLooperDelegate, UIDocumentPickerDelegate, PlaygroundLiveViewMessageHandler {
    
    private var animator: TurtleAnimator?
    
    private var cords: [[Operation]] = []
    
    private var layers: [CAShapeLayer] = [] {
        willSet {
            self.layers.forEach { layer in
                layer.removeFromSuperlayer()
            }
        }
        didSet {
            self.layers.forEach { layer in
                self.layerView.layer.addSublayer(layer)
            }
        }
    }
    
    private var layerView: UIView
    // private var url: URL
    
    init() {
        
        self.layerView = UIView()
        
        super.init(nibName: nil, bundle: nil)
        
        layerView.frame = self.view.frame
        layerView.bounds = self.view.bounds
        
        
        self.view.addSubview(layerView)
        self.animate(view: layerView)
        
        let button = UIButton()
        button.setTitle("Export EXP", for: .normal)
        
        self.view.addSubview(button)
        
        button.translatesAutoresizingMaskIntoConstraints = false
        
        button.centerXAnchor.constraint(equalTo: self.view.centerXAnchor).isActive = true
        button.widthAnchor.constraint(equalToConstant: 125).isActive = true
        button.heightAnchor.constraint(equalToConstant: 50).isActive = true
        button.bottomAnchor.constraint(equalTo: self.view.bottomAnchor, constant: -150).isActive = true
        button.addTarget(self, action: #selector(onExportPressed), for: .touchUpInside)
        
        
    }
    
    @objc func onExportPressed() {
        let documentPicker = UIDocumentPickerViewController(forOpeningContentTypes: [.folder])
        documentPicker.delegate = self
        documentPicker.modalPresentationStyle = .overFullScreen
        
        present(documentPicker, animated: true)
    }
    
    /// delegate method, when the user selects a file
    public func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
        guard let saveLocation = urls.first else { return }
        let exp = Data(self.toEXP())
        
        if saveLocation.startAccessingSecurityScopedResource() {
            defer {
                saveLocation.stopAccessingSecurityScopedResource()
            }
            
            do {
                let contents = try FileManager.default.contentsOfDirectory(at: saveLocation,
                                                                           includingPropertiesForKeys: nil)
                var savedFileName = "expTest"
                savedFileName += UUID().uuidString.split(separator: "-").last! + ".exp"
                
                try exp.write(to: saveLocation.appendingPathComponent(savedFileName))
                
            } catch {
                print(error.localizedDescription)
            }
        }
    }
    
    
    public func animate(view: UIView) {
        
        let layers = self.layers
        
        CATransaction.begin()
        CATransaction.disableActions()
        
        layers.forEach { layer in
            layer.removeAllAnimations()
            layer.strokeEnd = 0
        }
        CATransaction.commit()
        self.animator = TurtleAnimator(layers, showTurtle: true)
    }
    
    fileprivate func turtleAnimatorDidEnd(_ animator: TurtleAnimator) {
        self.animator = nil
    }
    
    func translate(_ position: [Double], center: CGPoint) -> CGPoint {
        let x = center.x + CGFloat(position[0])
        let y = center.y + (CGFloat(position[1]) * -1)
        let point = CGPoint(x: CGFloat(position[0] + 100), y: CGFloat(position[1]) + 100)
        return point
    }
    
    public func makeLayers(cords: [[Operation]]) -> [CAShapeLayer] {
        var layers = [CAShapeLayer]()
        let center = CGPoint(x: self.view.frame.width / 2, y: self.view.frame.height / 2)
        
        print(center)
        
        self.cords = cords
        
        for cord in cords {
            
            if (cord[0].type == .jump) {
                continue
            }
            
            let path = UIBezierPath()
            path.lineWidth = 5
            path.move(to: self.translate(cord[0].cord, center: center))
            path.addLine(to: self.translate(cord[1].cord, center: center))
            
            let layer = CAShapeLayer()
            layer.frame = self.view.bounds
            layer.path = path.cgPath
            layer.strokeColor = UIColor.green.cgColor
            layer.fillColor = UIColor.blue.cgColor
            layer.lineWidth = 5
            layers.append(layer)
            
            
        }
        
        
        return layers
        
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func receive(_ message: PlaygroundValue) {
        
        self.layers.forEach { layer in
            layer.removeFromSuperlayer()
        }
        
        guard case let .array(cords) = message else { return }
        let cordsPure: [[Operation]] = cords.map {
            guard case let .array(cordSet) = $0 else {
                
                let text = UITextView()
                text.text = "aaa"
                text.textColor = UIColor.white
                text.frame = view.frame
                text.bounds = view.bounds
                view.addSubview(text)
                return [Operation(type: .jump, cord: [200, 0])]
                
            }
            let cordSetPure: [Operation] = cordSet.map {
                guard case var .dictionary(cord) = $0 else {
                    let text = UITextView()
                    text.text = "bbb"
                    text.textColor = UIColor.white
                    text.frame = view.frame
                    text.bounds = view.bounds
                    view.addSubview(text)
                    return Operation(type: .jump, cord: [100, 0])
                    
                }
                
                guard case let .integer(type) = cord["type"] else {
                    let text = UITextView()
                    text.text = "ccc"
                    text.textColor = UIColor.white
                    text.frame = view.frame
                    text.bounds = view.bounds
                    view.addSubview(text)
                    return Operation(type: .jump, cord: [100, 0])
                    
                }
                
                guard case let .array(finalCordPlayground) = cord["cord"] else {
                    let text = UITextView()
                    text.text = "ddd"
                    text.textColor = UIColor.white
                    text.frame = view.frame
                    text.bounds = view.bounds
                    view.addSubview(text)
                    return Operation(type: .jump, cord: [100, 0])
                }
                
                let finalCord: [Double] = finalCordPlayground.map {
                    guard case let .floatingPoint(val) = $0 else { return 0 }
                    return val
                }
                
                return Operation(type: type == 0 ? .jump : .move, cord: finalCord)
            }
            return cordSetPure
        }
        
        self.layers = self.makeLayers(cords: cordsPure)
        self.animate(view: self.layerView)
        
        print("Hello World!")
    }
    
    func toEXP() -> [UInt8] {
        var expArray: [Int] = []
        let pixels_per_mm: Double = 5
        var scale: Double = 10 / pixels_per_mm
        var lastStitch: [[Int]]? = nil
        var hasFirst = false
        var origin: (Double, Double)
        
        func move(x: Int, y: Int) {
            var yy = Double(y * -1);
            var xx = Double(x);
            if (xx < 0) { xx += 256 }
            expArray.append(Int(round(xx)))
            if (yy < 0) { yy += 256 }
            expArray.append(Int(round(yy)))
        }
        
        for i in self.cords {
            
            let start = i[0]
            let end = i[1]
            
            origin = (start.cord[0], start.cord[1])
            
            let x1 = round(end.cord[0] * scale) - origin.0
            let y1 = round(end.cord[1] * scale) - origin.1
            let x0 = round(start.cord[0] * scale) - origin.0
            let y0 = round(start.cord[1] * scale) - origin.1
            
            var sum_x: Double = 0
            var sum_y: Double = 0
            var dmax = max(abs(x1 - x0), abs(y1 - y0))
            var dsteps = abs(dmax / 127)
            
            // 126 73 73
            
            if (dsteps <= 1) {
                if start.type == .jump {
                    expArray.append(0x80)
                    expArray.append(0x04)
                } else {
                    expArray.append(0x00)
                    expArray.append(0x00)
                }
                move(x: Int(round(x1 - x0)), y: Int(round(y1 - y0)))
            } else {
                for j in 0...Int(dsteps.rounded(.up) - 1) {
                    if start.type == .jump {
                        expArray.append(0x80)
                        expArray.append(0x04)
                    } else {
                        expArray.append(0x00)
                        expArray.append(0x00)
                    }
                    if (j < Int(dsteps.rounded(.up)) - 1) {
                        move(x: Int((x1 - x0)/dsteps), y: Int((y1 - y0)/dsteps))
                        sum_x += (x1 - x0)/dsteps
                        sum_y += (y1 - y0)/dsteps
                    } else {
                        move(x: Int(round(x1 - x0 - sum_x)), y: Int(round(y1 - y0 - sum_y)))
                    }
                }
            }
            hasFirst = true
        }
        
        // var uIntArray: [UInt8] = [UInt8](repeating: 0, count: expArray.count)
        var uIntArray: [UInt8] = expArray.map(UInt8.init)
        return uIntArray
        
        // return [UInt8](repeating: 0, count: 1)
        
    }
    
}

// Instantiate a new instance of the live view from BookCore and pass it to PlaygroundSupport.
PlaygroundPage.current.liveView = SomeViewController()
